package com.inmemory;

public enum Constraint {
  NOT_NULL("not null");

  Constraint() {

  }
}
