package com.parking.model;

public class CarParkingSlot extends ParkingSlot{


    public CarParkingSlot(int slotNumber, boolean availability)
    {
        this.slotNumber = slotNumber;
        this.availability = availability;
    }


}
