package com.parking.model;

public class TwoWheeler extends Vehicle{

    public TwoWheeler(String vechileNo){
       super(VechileType.TWOWHEELER,vechileNo);
    }
}
