package com.parking.model;

public class Car extends Vehicle{
    public Car(String vechileNo){
        super(VechileType.CAR,vechileNo);
    }
}
