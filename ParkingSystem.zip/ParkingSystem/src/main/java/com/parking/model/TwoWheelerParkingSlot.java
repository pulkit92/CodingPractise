package com.parking.model;

public class TwoWheelerParkingSlot extends ParkingSlot {


    public TwoWheelerParkingSlot(int slotNumber, boolean availability) {
        this.slotNumber = slotNumber;
        this.availability = availability;
    }

}
