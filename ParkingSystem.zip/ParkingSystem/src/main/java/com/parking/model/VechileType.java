package com.parking.model;

public enum VechileType {
    CAR,TWOWHEELER;
}
